-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 08, 2023 at 12:01 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurent`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'yami@', '2815');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(10) NOT NULL,
  `category_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `category_name`) VALUES
(3, 'Non-Veg'),
(6, 'Veg'),
(8, 'Drinks');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(20) NOT NULL,
  `Name` varchar(20) NOT NULL,
  `Phone_no` varchar(20) NOT NULL,
  `Designation` varchar(20) NOT NULL,
  `Address` varchar(40) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `Name`, `Phone_no`, `Designation`, `Address`, `username`, `password`) VALUES
(3, 'karan', '9877701681', 'manager', 'Hoshiarpur', 'priya@', '2828'),
(4, 'Simer', '9874563212', 'cook', 'Adampur', 'simar@', '123');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(20) NOT NULL,
  `food_name` varchar(20) NOT NULL,
  `code` varchar(20) NOT NULL,
  `category` varchar(20) NOT NULL,
  `price` varchar(20) NOT NULL,
  `size` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `food_name`, `code`, `category`, `price`, `size`) VALUES
(4, 'Pizza', '2001', 'Veg', '180', 'Small'),
(5, 'oreo shake', '3001', 'Drinks', '60', 'Medium'),
(6, ' Manchurian', '1023', 'Veg', '100', 'Small'),
(7, 'Biryani', '4021', 'Non-Veg', '200', 'Medium'),
(8, 'Butter Chicken', '4013', 'Non-Veg', '300', 'Small'),
(9, 'Coffee', '3002', 'Drinks', '40', 'Medium'),
(10, 'Burger', '2006', 'Veg', '40', 'Medium'),
(11, 'Chocolate Shake', '3004', 'Drinks', '60', 'Medium'),
(12, 'Red Pasta', '2008', 'Veg', '90', 'Medium'),
(13, 'White Pasta', '2009', 'Veg', '90', 'Medium');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(20) NOT NULL,
  `table_no` varchar(20) NOT NULL,
  `food_code` varchar(20) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `total_bill` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `member_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `table_no`, `food_code`, `quantity`, `total_bill`, `status`, `member_id`) VALUES
(1, '3', '001', '2', '360', 'DELIVERED', 'priya@'),
(2, '2', '001', '3', '540', 'DELIVERED', 'simar@'),
(3, '4', '10', '1', '120', 'DELIVERED', 'priya@'),
(5, '3', '10', '2', '120', 'DELIVERED', 'simar@'),
(6, '3', '4013', '1', '300', 'PENDING', 'priya@'),
(7, '7', '3004', '2', '120', 'PENDING', 'simar@'),
(8, '1', '1023', '2', '200', 'PENDING', 'priya@'),
(9, '2', '4021', '2', '400', 'PENDING', 'priya@'),
(10, '3', '1023', '1', '100', 'PENDING', 'priya@'),
(11, '5', '4013', '2', '600', 'PENDING', 'priya@');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
