from tkinter import *
import add_category,add_menu,add_members
import view_category,view_menu,view_members,view_admin_order
from PIL import Image,ImageTk
from tkinter import ttk 

class AdminDashboard:
    def __init__(self):
        self.root=Tk()
        self.root.geometry("1550x800+0+0")
        self.root.title("RESTAURANT FULL DETAILS")

    def dashboard_widgets(self):
        
        img2=Image.open(r"D:\pythonProject\admin\images\restaurant-logo-design.jpg")
        img2=img2.resize((500,660),Image.LANCZOS)
        self.photoimg2=ImageTk.PhotoImage(img2)
        self.iblImg=Label(self.root,image=self.photoimg2,bd=4,relief=RIDGE)
        self.iblImg.place(x=0,y=140,width=500,height=660)
       
        lbl_title=Label(self.root,text="ADMIN DASHBOARD",font=("Times New Roman",40,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE)
        lbl_title.place(x=0,y=0,width=1550,height=140)
        # Add category
        
        self.addCategory_frame_button = Button(self.root,text="Add Category",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_addCategoryPage_frame)
        self.addCategory_frame_button.place(x=550,y=200,width=400,height=50)

        #view category
        self.viewCategory_frame_button = Button(self.root,text="View Category",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_viewCategoryPage_frame)
        self.viewCategory_frame_button.place(x=1000,y=200,width=400,height=50)
        
        #add menu
        
        self.addMenu_frame_button = Button(self.root,text="Add Menu",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_addMenuPage_frame)
        self.addMenu_frame_button.place(x=550,y=280,width=400,height=50)

        #view menu
        self.viewMenu_frame_button = Button(self.root,text="View Menu",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_viewMenuPage_frame)
        self.viewMenu_frame_button.place(x=1000,y=280,width=400,height=50)
        
        #add members
        
        self.addMembers_frame_button = Button(self.root,text="Add Members",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_addMembersPage_frame)
        self.addMembers_frame_button.place(x=550,y=360,width=400,height=50)

        #view members
        self.viewMembers_frame_button = Button(self.root,text="View Members",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_viewMembersPage_frame)
        self.viewMembers_frame_button.place(x=1000,y=360,width=400,height=50)
        

        #view orders
        self.viewOrders_frame_button = Button(self.root,text="View Orders",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_viewOrdersPage_frame)
        self.viewOrders_frame_button.place(x=550,y=440,width=850,height=50)
   
    def open_addCategoryPage_frame(self):
        self.root.destroy()
        i=add_category.AddCategory()
        i.add_category_widgets()
    
    def open_viewCategoryPage_frame(self):
        self.root.destroy()
        k=view_category.viewCategory()
        k.view_category_widgets()
    def open_addMenuPage_frame(self):
        self.root.destroy()
        a=add_menu.AddMenu()
        a.add_menu_widgets()

    def open_viewMenuPage_frame(self):
        self.root.destroy()
        s = view_menu.ViewMenu()
        s.view_menu_widgets()

    def open_addMembersPage_frame(self):
        self.root.destroy()
        a=add_members.AddMembers()
        a.add_members_widgets()
    def open_viewMembersPage_frame(self):
        self.root.destroy()
        s = view_members.ViewMembers()
        s.view_members_widgets()


    def open_viewOrdersPage_frame(self):
        self.root.destroy()
        v=view_admin_order.ViewAdminOrder()
        v.view_admin_order_widgets()
   
if __name__=="__main__":
    k=AdminDashboard()
    k.dashboard_widgets()
    k.root.mainloop()