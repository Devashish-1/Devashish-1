from tkinter import *
from tkinter import ttk
import database,add_order
from tkinter import messagebox
class ViewDeliveredOrder:
    def __init__(self):
        self.root=Tk()
        self.root.geometry("800x800")
        self.root.title("DELIVERED ORDERS")

    def view_delivered_order_widgets(self):
        self.f=Frame(self.root,bg="Lightyellow")
        self.f.place(x=0,y=0,width=800,height=800)

        self.tree_view=ttk.Treeview(self.f,columns=("A","B","C","D","E","F","G","H","I"))
        
        self.tree_view.heading("#0",text="Id")
        self.tree_view.column("#0",width=70)

        self.tree_view.heading("#1",text="Table no")
        self.tree_view.column("#1",width=90)

        self.tree_view.heading("#2",text="Food Code")
        self.tree_view.column("#2",width=90)

        self.tree_view.heading("#3",text="quantity")
        self.tree_view.column("#3",width=90)
       
        self.tree_view.heading("#4",text="Total Bill")
        self.tree_view.column("#4",width=90)

        self.tree_view.heading("#5",text="Status")
        self.tree_view.column("#5",width=90)

        
        for i in database.show_all_delivered_orders():
             self.tree_view.insert("",0,text=i[0],values=(i[1],i[2],i[3],i[4],i[5])) 
        
        self.tree_view.bind("<Double-Button-1>",self.tree_view_actions)
        self.tree_view.place(x=15,y=10,width=800,height=550)
    
    def tree_view_actions(self,e):
        row=self.tree_view.focus()
        print("Focus row-",row)

        column_id=self.tree_view.identify_column(e.x)
        print("Column Id - ", column_id)
        
        focused_row_data = self.tree_view.item(row)
        print("Focused row data - ", focused_row_data)
        
        selected_order_id = focused_row_data.get("text")
        print("Selected order id - ", selected_order_id)
        
        
        
                         
if __name__=="__main__":
    k=ViewDeliveredOrder()
    k.view_delivered_order_widgets()
    k.root.mainloop()