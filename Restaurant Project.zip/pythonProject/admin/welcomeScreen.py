from tkinter import *
import admin_login
import members_loginPage
from PIL import Image,ImageTk
from tkinter import ttk 

class WelcomeScreen:
    def __init__(self):
        self.root=Tk()
        self.root.title("Restaurant Management system")
        self.root.geometry("1550x800+0+0")
        
    def widgets(self):
        img2=Image.open(r"D:\pythonProject\admin\images\restaurant-logo-design.jpg")
        img2=img2.resize((230,140),Image.LANCZOS)
        self.photoimg2=ImageTk.PhotoImage(img2)
        self.iblImg=Label(self.root,image=self.photoimg2,bd=4,relief=RIDGE)
        self.iblImg.place(x=0,y=0,width=230,height=140)

        lbl_title=Label(self.root,text="RESTAURANT MANAGEMENT SYSTEM",font=("Times New Roman",40,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE)
        lbl_title.place(x=230,y=0,width=1320,height=140)
 
        self.f=Frame(self.root,bd=4,relief=RIDGE)
        self.f.place(x=0,y=140,width=1550,height=620)

        lbl_button=Button(self.f,text="Admin Login ",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_adminPage_frame)
        lbl_button.place(x=0,y=0,width=230)

        member_button=Button(self.f,text="Members Login",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_MembersLoginPage_frame)
        member_button.place(x=0,y=55,width=230)
        
        img3=Image.open(r"D:\pythonProject\admin\images\rest.jpg")
        img3=img3.resize((1310,600),Image.LANCZOS)
        self.photoimg3=ImageTk.PhotoImage(img3)
        self.iblImg=Label(self.f,image=self.photoimg3,bd=4,relief=RIDGE)
        self.iblImg.place(x=225,y=0,width=1330,height=600)

        img4=Image.open(r"D:\pythonProject\admin\images\food.jpeg")
        img4=img4.resize((230,230),Image.LANCZOS)
        self.photoimg4=ImageTk.PhotoImage(img4)
        self.iblImg=Label(self.f,image=self.photoimg4,bd=4,relief=RIDGE)
        self.iblImg.place(x=0,y=120,width=230,height=240)

        img5=Image.open(r"D:\pythonProject\admin\images\cooks.jpeg")
        img5=img5.resize((230,230),Image.LANCZOS)
        self.photoimg5=ImageTk.PhotoImage(img5)
        self.iblImg=Label(self.f,image=self.photoimg5,bd=4,relief=RIDGE)
        self.iblImg.place(x=0,y=360,width=230,height=240)
        
    def open_adminPage_frame(self):
        self.root.destroy()
        a = admin_login.admin_login()
        a.admin_login_widgets()
    
    def open_MembersLoginPage_frame(self):
        self.root.destroy()
        j=members_loginPage.MembersLogin()
        j.members_login_widgets()

if __name__=="__main__":
    k=WelcomeScreen()
    k.widgets()
    k.root.mainloop()
