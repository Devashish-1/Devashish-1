from tkinter import *
import database,admin_dashboard,welcomeScreen
from tkinter import messagebox
from tkinter import ttk 
from PIL import Image,ImageTk
class admin_login:
    def __init__(self):
        self.root=Tk()
        self.root.title("Login Page")
        self.root.geometry("1550x800+0+0")
    def admin_login_widgets(self):
        img2=Image.open(r"D:\pythonProject\admin\images\login_page.jpg")
        img2=img2.resize((1550,800),Image.LANCZOS)
        self.photoimg2=ImageTk.PhotoImage(img2)
        self.iblImg=Label(self.root,image=self.photoimg2,bd=4,relief=RIDGE)
        self.iblImg.place(x=0,y=0)

        
        
        self.f=Frame(self.root,bg="LightGrey")
        self.f.place(x=550,y=150,width=500,height=500)

        
        self.title=Label(self.f,text="Admin Login Page",font=("Time New Roman",30,"bold"),bg="LightGrey")
        self.title.place(x=90,y=30)
        self.username=Label(self.f,text="Username:",font=("Time New Roman",16,),bg="LightGrey")
        self.username.place(x=80,y=140)
        self.username_entry=Entry(self.f)
        self.username_entry.place(x=100,y=180,height=30,width=250)
        self.password=Label(self.f,text="Password:",font=("Time New Roman",16),bg="LightGrey")
        self.password.place(x=80,y=240)
        self.password_entry=Entry(self.f)
        self.password_entry.place(x=100,y=280,height=30,width=250)
        self.b=Button(self.f,text="Login",bg="Black",fg="LightGrey",font=("Times New Roman",14,"bold"),command=self.run_admin_login_query)
        self.b.place(x=160,y=360,width=130)

        self.b=Button(self.f,text="<BACK",bg="LightGrey",font=("Times New Roman",14,"bold"),command=self.open_welcomePage_frame)
        self.b.place(x=360,y=450,width=130)

    def run_admin_login_query(self):
        admin_details=(self.username_entry.get(),self.password_entry.get())
        print("Username and password is ",admin_details)
        result=database.admin_login(admin_details)
        if result:
            messagebox.showinfo("Message","Login successfull")
            self.root.destroy()
            d=admin_dashboard.AdminDashboard()
            d.dashboard_widgets()
        else:
            messagebox.showinfo("Message","Incorrect username or password")

    def open_welcomePage_frame(self):
        self.root.destroy()
        k=welcomeScreen.WelcomeScreen()
        k.widgets()
            

if __name__=="__main__":
    j=admin_login()
    j.admin_login_widgets()
    j.root.mainloop()