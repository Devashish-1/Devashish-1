from tkinter import *
from tkinter import ttk
import database,add_order

class ViewAdminOrder:
    def __init__(self,logged_in_member=""):
        self.root = Tk()
        self.loggedInMember = logged_in_member
        self.root.geometry("800x800")
        self.root.title("VIEW ORDER")

    def view_admin_order_widgets(self):
        self.f = Frame(self.root,bg="LightGrey")
        self.f.place(x=0,y=0,width=800,height=800)

        self.tree_view = ttk.Treeview(self.f,columns=("A","B","C","D","E","F","G"))

        self.tree_view.heading("#0",text="Id")
        self.tree_view.column("#0",width=90)

        self.tree_view.heading("#1",text="Table no")
        self.tree_view.column("#1",width=90)

        self.tree_view.heading("#2",text="Food Code")
        self.tree_view.column("#2",width=90)

        self.tree_view.heading("#3",text="quantity")
        self.tree_view.column("#3",width=90)
        
        self.tree_view.heading("#4",text="Total Bill")
        self.tree_view.column("#4",width=90)

        self.tree_view.heading("#5",text="Current status")
        self.tree_view.column("#5",width=90)                                        
        
        self.tree_view.heading("#6",text="Member Id")
        self.tree_view.column("#6",width=90)
        
        for i in database.show_all_admin_order():
            self.tree_view.insert("",0,text=i[0],values=(i[1],i[2],i[3],i[4],i[5],i[6]))    
        self.tree_view.place(x=10,y=10)

if __name__=="__main__":
    v = ViewAdminOrder()
    v.view_admin_order_widgets()
    v.root.mainloop()