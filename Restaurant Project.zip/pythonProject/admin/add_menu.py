from tkinter import *
from tkinter.ttk import Combobox
from tkinter import messagebox
import database,view_menu,admin_dashboard
from PIL import Image,ImageTk
from tkinter import ttk 
class AddMenu:
    def __init__(self,selected_menu_data=""):
        self.root=Tk()
        self.root.geometry("1550x800+0+0")
        #self.root.withdraw()

        self.selectedMenuData = selected_menu_data
        
        if self.selectedMenuData:
            self.root.title('UPDATE MENU')
        else:
            self.root.title('ADD MENU')
        
        img=Image.open("admin/images/menu-food.jpg")
        print("Image path - ", img)
        img=img.resize((1550,800),Image.LANCZOS)
        self.photoimg=ImageTk.PhotoImage(img)
        self.iblImg=Label(self.root,image=self.photoimg,bd=4,relief=RIDGE)
        self.iblImg.place(x=0,y=0)
        
    def add_menu_widgets(self):
        
        

        self.f=Frame(self.root,bd=4,bg="Black",relief=RIDGE)
        self.f.place(x=450,y=170,width=600,height=460)


        #food name
        self.food_name=Label(self.f,text="Food Name:",font=("Times New Roman",30,"bold"),bg="Black",fg="gold")
        self.food_name.place(x=65,y=60)
        self.food_name_entry=Entry(self.f,font=("Times New Roman",12))
        self.food_name_entry.place(x=300,y=70,height=35,width=250)
        
        #food code
        self.food_code=Label(self.f,text="Food Code:",font=("Times New Roman",30,"bold"),bg="Black",fg="gold")
        self.food_code.place(x=65,y=120)
        self.food_code_entry=Entry(self.f,font=("Century Gothic",12))
        self.food_code_entry.place(x=300,y=125,height=35,width=250)
        
        #category
        self.food_name=Label(self.f,text="Category:",font=("Times New Roman",30,"bold"),bg="Black",fg="gold")
        self.food_name.place(x=65,y=180)

        self.type_list=[]
        for i in database.show_all_category():
            self.type_list.append(i[1]) # 0 to get id,1 for text
        self.type_combobox=Combobox(self.f,values=self.type_list,font=("Times New Roman",12),state="readonly")
        self.type_combobox.place(x=300,y=185,height=35,width=250)        
        
        #price
        self.food_price=Label(self.f,text="Price:",font=("Times New Roman",30,"bold"),bg="Black",fg="gold")
        self.food_price.place(x=65,y=240)
        self.food_price_entry=Entry(self.f,font=("Times New Roman",12))
        self.food_price_entry.place(x=300,y=245,height=35,width=250)
        
        #size
        self.food_size=Label(self.f,text="Food Size:",font=("Times New Roman",30,"bold"),bg="Black",fg="gold")
        self.food_size.place(x=65,y=300)
        self.type_list = ["Small","Medium","Large"]
        self.type_combobox1=Combobox(self.f,values=self.type_list,font=("Google Sans",12),state="readonly")
        self.type_combobox1.place(x=300,y=305,height=35,width=250)
 
        self.b = Button(self.f,text="< BACK",bg='black',fg="gold" ,font=("Times New Roman",15),command=self.open_admin_dashboard_frame)
        self.b.place(x=450, y=410,width=150)

        if self.selectedMenuData:
            print("selected menu data - ", self.selectedMenuData)
            result = dict(self.selectedMenuData).get("values")
            self.food_name_entry.insert(0,result[0])
            self.food_code_entry.insert(0,result[1])
            self.type_combobox.set(result[2])
            self.food_price_entry.insert(0,result[3])
            self.type_combobox1.set(result[4])
            
            self.b=Button(self.f, text="UPDATE",bg='gold', font=("Times New Roman",15),command=self.run_update_menu_query)
            self.b.place(x=250,y=380,width=150)
        else:
            self.b=Button(self.f, text="Submit",bg='gold', font=("Times New Roman",15),command=self.run_add_menu_query)
            self.b.place(x=250,y=380,width=150)

        #self.root.mainloop()

    def run_add_menu_query(self):
        menu_items=(self.food_name_entry.get(),self.food_code_entry.get(),self.type_combobox.get(),self.food_price_entry.get(),self.type_combobox1.get())
        print("All menu items are:",menu_items)
        result=database.add_menu_info(menu_items)
        if result:
            messagebox.showinfo("Message"," Menu is  added successfully")
            self.root.destroy()
            s = view_menu.ViewMenu()
            s.view_menu_widgets()
        else:
            messagebox.showinfo("Message","Alert!,Something went wrong")

    def run_update_menu_query(self):
        updated_menu_details = (self.food_name_entry.get(),self.food_code_entry.get(),self.type_combobox.get(),self.food_price_entry.get(),self.type_combobox1.get(),
            dict(self.selectedMenuData).get("text")
        )

        update_result = database.update_menu(updated_menu_details)
        print("Update result - ", update_result)
        if update_result:
            messagebox.showinfo("Message","menu updated successfully")
            self.root.destroy()
            s= view_menu.ViewMenu()
            s.view_menu_widgets()
        else:
            messagebox.showwarning("Alert!","Something went wrong")

        
    def open_admin_dashboard_frame(self):
        self.root.destroy()
        k=admin_dashboard.AdminDashboard()
        k.dashboard_widgets()

if __name__=="__main__":
    a=AddMenu()
    a.add_menu_widgets()
    a.root.mainloop()















     