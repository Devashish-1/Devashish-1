from tkinter import *
import database,member_dashboard,welcomeScreen
from tkinter import messagebox
from tkinter import ttk 
from PIL import Image,ImageTk

class MembersLogin:
    def __init__(self):
        self.root=Tk()
        self.root.title("Login Page")
        self.root.geometry("1550x800+0+0")
    def members_login_widgets(self):
        img2=Image.open(r"D:\pythonProject\admin\images\member-login-pic.jpg")
        img2=img2.resize((1550,800),Image.LANCZOS)
        self.photoimg2=ImageTk.PhotoImage(img2)
        self.iblImg=Label(self.root,image=self.photoimg2,bd=4,relief=RIDGE)
        self.iblImg.place(x=0,y=0)

        
        
        self.f=Frame(self.root,bg="firebrick1")
        self.f.place(x=850,y=170,width=500,height=550)

        
        self.title=Label(self.f,text="Member Login Page",font=("Time New Roman",30,"bold"),bg="firebrick1",fg="White")
        self.title.place(x=80,y=30)
        self.username=Label(self.f,text="Username:",font=("Time New Roman",16,),bg="firebrick1",fg="White")
        self.username.place(x=80,y=140)
        self.username_entry=Entry(self.f,font=("Google Sans",12))
        self.username_entry.place(x=100,y=180,height=30,width=250)
        self.password=Label(self.f,text="Password:",font=("Time New Roman",16),bg="firebrick1",fg="White")
        self.password.place(x=80,y=240)
        self.password_entry=Entry(self.f,font=("Google Sans",12))
        self.password_entry.place(x=100,y=280,height=30,width=250)
        self.b=Button(self.f,text="Login",bg="White",fg="firebrick1",font=("Times New Roman",14,"bold"),command=self.run_members_login_query)
        self.b.place(x=160,y=360,width=130)
    
        self.b=Button(self.f,text="<BACK",bg="firebrick1",fg="White",font=("Times New Roman",14,"bold"),command=self.open_welcomePage_frame)
        self.b.place(x=350,y=470,width=130)

    def run_members_login_query(self):
        members_details=(self.username_entry.get(),self.password_entry.get())
        print("Username and password is ",members_details)
        result=database.members_login(members_details)
        if result:
            messagebox.showinfo("Message","Login successfull")
            self.root.destroy()
            d=member_dashboard.MemberDashboard(result)
            d.dashboard_widgets()
        else:
            messagebox.showinfo("Message","Incorrect username or password")

    def open_welcomePage_frame(self):
        self.root.destroy()
        k=welcomeScreen.WelcomeScreen()
        k.widgets()

if __name__=="__main__":
    j=MembersLogin()
    j.members_login_widgets()
    j.root.mainloop()