from tkinter import *
import database,view_category,admin_dashboard
from tkinter import messagebox
from PIL import Image,ImageTk
from tkinter import ttk 
class AddCategory:
    def __init__(self,selected_category_data=""):
        self.root=Tk()

        self.selectedCategoryData = selected_category_data
        
        if self.selectedCategoryData:
            self.root.title('UPDATE CATEGORY')
        else:
            self.root.title('ADD CATEGORY')
        
        # self.root.geometry("600x600")
        # self.root.title("Add Category | Restaurent Management")
        self.root.geometry("1550x800+0+0")
        self.root.title("Add Category | Restaurent Management")

    def add_category_widgets(self):
        img2=Image.open(r"D:\pythonProject\admin\images\add-category.jpg")
        img2=img2.resize((1550,800),Image.LANCZOS)
        self.photoimg2=ImageTk.PhotoImage(img2)
        self.iblImg=Label(self.root,image=self.photoimg2,bd=4,relief=RIDGE)
        self.iblImg.place(x=0,y=0)

        self.f=Frame(self.root,bg="LightGrey")
        self.f.place(x=800,y=50,width=600,height=400)
        
        self.category=Label(self.f,text="Category Name:",bg="LightGrey",fg="tan4",font=("Times New Roman",30,"bold"))
        self.category.place(x=120,y=70)
        
        self.category_name_entry=Entry(self.f,font=("Century Gothic",12))
        self.category_name_entry.place(x=180,y=130,height=35,width=300)
        
        self.b = Button(self.f, text='< BACK',bg='lightGrey',fg='tan4', font=("Times New Roman",12),command=self.open_admin_dashboard_frame)
        self.b.place(x=480,y=350,width=100)

        if self.selectedCategoryData:
            print("selected category data - ", self.selectedCategoryData)
            result = dict(self.selectedCategoryData).get("values")
            self.category_name_entry.insert(0,result[0])
            
            self.b = Button(self.f, text='UPDATE',bg='tan4',fg='lightGrey', font=("Times New Roman",12), command=self.run_update_category_query)
            self.b.place(x=230, y=220,width=170,height=30)
        else:
            self.b = Button(self.f, text='SUBMIT',bg='tan4',fg='lightGrey', font=("Century Gothic bold",12), command=self.run_add_category_query)
            self.b.place(x=230, y=220,width=170,height=30)
    
    def open_admin_dashboard_frame(self):
        self.root.destroy()
        k=admin_dashboard.AdminDashboard()
        k.dashboard_widgets()

    def run_add_category_query(self):
        showCategory=(self.category_name_entry.get(),)
        print("Category is",showCategory)
        result=database.add_category_info(showCategory)
        if result:
            messagebox.showinfo("Message","category added successfully")
            self.root.destroy()
            v = view_category.viewCategory()
            v.view_category_widgets()
        else:
            messagebox.showwarning("Alert!","Something went wrong")

    def run_update_category_query(self):
        updated_category_details = (self.category_name_entry.get(),
            dict(self.selectedCategoryData).get("text")
        )

        update_result = database.update_category(updated_category_details)
        print("Update result - ", update_result)
        if update_result:
            messagebox.showinfo("Message","category updated successfully")
            self.root.destroy()
            v = view_category.viewCategory()
            v.view_category_widgets()
        else:
            messagebox.showwarning("Alert!","Something went wrong")

if __name__=="__main__":
    i=AddCategory()
    i.add_category_widgets()
    i.root.mainloop()       