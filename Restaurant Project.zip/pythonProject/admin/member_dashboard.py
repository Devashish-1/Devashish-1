from tkinter import *
import add_order,view_member_order
from PIL import Image,ImageTk
from tkinter import ttk 
import view_delivered_orders,view_pending_orders
class MemberDashboard:
    def __init__(self,logged_in_member=""):
        self.root=Tk()
        self.loggedInMember = logged_in_member
        self.root.geometry("1550x800+0+0")
        self.root.title("RESTAURANT FULL DETAILS")

    def dashboard_widgets(self):
        img2=Image.open(r"D:\pythonProject\admin\images\restaurant-logo-design.jpg")
        img2=img2.resize((800,660),Image.LANCZOS)
        self.photoimg2=ImageTk.PhotoImage(img2)
        self.iblImg=Label(self.root,image=self.photoimg2,bd=4,relief=RIDGE)
        self.iblImg.place(x=0,y=140,width=800,height=660)
       
        lbl_title=Label(self.root,text="MEMBER DASHBOARD",font=("Times New Roman",40,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE)
        lbl_title.place(x=0,y=0,width=1550,height=140)
        # Add category
        
        self.addOrder_frame_button = Button(self.root,text="Add Order",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_addOrderPage_frame)
        self.addOrder_frame_button.place(x=1000,y=300,width=400,height=50)

        #view category
        self.viewOrder_frame_button = Button(self.root,text="View Order",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_viewOrderPage_frame)
        self.viewOrder_frame_button.place(x=1000,y=380,width=400,height=50)
        #pending
        self.addOrder_frame_button = Button(self.root,text="Pending Orders",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_pendingOrderPage_frame)
        self.addOrder_frame_button.place(x=1000,y=460,width=400,height=50)

        #delivered
        self.addOrder_frame_button = Button(self.root,text="Delivered orders",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_deliveredOrderPage_frame)
        self.addOrder_frame_button.place(x=1000,y=540,width=400,height=50)
        
        self.addOrder_frame_button = Button(self.root,text="logout",font=("Times New Roman",20,"bold"),bg="black",fg="gold",bd=4,relief=RIDGE,command=self.open_deliveredOrderPage_frame)
        self.addOrder_frame_button.place(x=1000,y=540,width=400,height=50)
        
        
    def open_addOrderPage_frame(self):
        self.root.destroy()
        s=add_order.AddOrder(logged_in_member=self.loggedInMember)
        s.add_order_widgets()
    
    def open_viewOrderPage_frame(self):
        self.root.destroy()
        a=view_member_order.ViewMembersOrder(logged_in_member=self.loggedInMember)
        a.view_members_order_widgets()

    def open_pendingOrderPage_frame(self):
        self.root.destroy()
        b=view_pending_orders.ViewPendingOrder()
        b.view_pending_order_widgets() 

    def open_deliveredOrderPage_frame(self):
        self.root.destroy()
        c=view_delivered_orders.ViewDeliveredOrder()
        c.view_delivered_order_widgets() 

if __name__=="__main__":
    k=MemberDashboard()
    k.dashboard_widgets()
    k.root.mainloop()